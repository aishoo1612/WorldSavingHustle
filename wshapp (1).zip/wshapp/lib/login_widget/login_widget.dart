/*
*  login_widget.dart
*  WSH IT
*
*  Created by WSH.
*  Copyright © 2018 WSH. All rights reserved.
    */

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wsh_it/landing_page_widget/landing_page_widget.dart';
import 'package:wsh_it/my_profile_widget/my_profile_widget.dart';
import 'package:wsh_it/values/values.dart';
import 'package:firebase_auth/firebase_auth.dart';

class LoginWidget extends StatefulWidget{
  @override
  _LoginWidgetState createState() => _LoginWidgetState() ;
}


class _LoginWidgetState extends State<LoginWidget> {
   var uEmail ;
   var uPassword ;



  void onLOGINPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => MyProfileWidget()));

  void onGoBackPressed(BuildContext context) => Navigator.push(context, MaterialPageRoute(builder: (context) => LandingPageWidget()));

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: Container(
        constraints: BoxConstraints.expand(),
        decoration: BoxDecoration(
          color: Color.fromARGB(255, 255, 255, 255),
        ),
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              bottom: 0,
              child: Image.asset(
                "assets/images/background-2.png",
                fit: BoxFit.cover,
              ),
            ),
            Positioned(
              left: 22,
              top: 19,
              right: 47,
              bottom: 32,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: Container(
                      width: 50,
                      height: 50,
                      child: FlatButton(
                        onPressed: () => this.onGoBackPressed(context),
                        color: Color.fromARGB(0, 0, 0, 0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(0)),
                        ),
                        textColor: Color.fromARGB(255, 0, 0, 0),
                        padding: EdgeInsets.all(0),
                        child: Icon(CupertinoIcons.back, color: Colors.white,)
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.only(left: 106, top: 118, right: 79),
                    child: Text(
                      "Login!",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color.fromARGB(255, 255, 255, 255),
                        fontFamily: "Product Sans",
                        fontWeight: FontWeight.w400,
                        fontSize: 40,
                      ),
                    ),
                  ),
                  Container(
                    height: 40,
                    margin: EdgeInsets.only(left: 25, top: 35, right: 1),
                    child: Positioned(
                      left: 0,
                      right: 0,
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 250, 250, 250),
                          border: Border.all(
                            width: 1,
                            color: Color.fromARGB(255, 112, 112, 112),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        ),
                        child: Container(
                          width: 189,
                          height: 20,
                          margin: EdgeInsets.only(left: 27),
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: "Email ID",
//                                  contentPadding: EdgeInsets.only(left: 15),
                              border: InputBorder.none,
                              suffixIcon: Opacity(
                                opacity: 0.45,
                                child: Image.asset(
                                  "assets/images/icons8-email-52-5.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ),
                            onChanged: (value){
                              setState(() {
                                uEmail = value ;
                              });
                            },
                            style: TextStyle(
                              color: AppColors.secondaryText,
                              fontFamily: "Product Sans",
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                            ),
                            maxLines: 1,
                            keyboardType: TextInputType.emailAddress,
                            autocorrect: false,
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 40,
                    margin: EdgeInsets.only(left: 25, top: 15, right: 1),
                    child: Positioned(
                      left:0,
                      right: 0,
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                          color: Color.fromARGB(255, 250, 250, 250),
                          border: Border.all(
                            width: 1,
                            color: Color.fromARGB(255, 112, 112, 112),
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        ),
                        child: Container(
                          width: 189,
                          height: 20,
                          margin: EdgeInsets.only(left: 27),
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: "Password",
//                              contentPadding: EdgeInsets.all(0),
                              border: InputBorder.none,
                              suffixIcon: Opacity(
                                opacity: 0.45,
                                child: Image.asset(
                                  "assets/images/icons8-password-52-5.png",
                                  fit: BoxFit.none,
                                ),
                              ),
                            ),

                            style: TextStyle(
                              color: AppColors.secondaryText,
                              fontFamily: "Product Sans",
                              fontWeight: FontWeight.w400,
                              fontSize: 16,
                            ),
                            obscureText: true,
                            maxLines: 1,
                            autocorrect: false,
                            onChanged: (value) {
                              setState(() {
                                uPassword = value;
                              });
                            },
                            ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    height: 37,
                    margin: EdgeInsets.only(left: 92, top: 34, right: 67),
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 250, 250, 250),
                      border: Border.all(
                        width: 1,
                        color: Color.fromARGB(255, 112, 112, 112),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(181, 0, 0, 0),
                          offset: Offset(0, 3),
                          blurRadius: 6,
                        ),
                      ],
                      borderRadius: BorderRadius.all(Radius.circular(18.5)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          width: 63,
                          height: 24,
                          child: FlatButton(
                            onPressed: () { this.onLOGINPressed(context);
                              FirebaseAuth.instance.createUserWithEmailAndPassword(
                              email: uEmail, password: uPassword).then((user ) {Navigator.of(context).pushReplacementNamed('/homepage'); }).catchError((e){
                              print(e);
                              });
                            },
                            color: Color.fromARGB(0, 0, 0, 0),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.all(Radius.circular(0)),
                            ),
                            textColor: Color.fromARGB(255, 51, 51, 51),
                            padding: EdgeInsets.all(0),
                            child: Text(
                              "LOGIN",
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                color: Color.fromARGB(255, 51, 51, 51),
                                fontFamily: "Product Sans",
                                fontWeight: FontWeight.w700,
                                fontSize: 20,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Spacer(),
                  Align(
                    alignment: Alignment.topCenter,
                    child: Text(
                      "@WorldSavingHustle",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color.fromARGB(255, 255, 255, 255),
                        fontFamily: "Product Sans",
                        fontWeight: FontWeight.w400,
                        fontSize: 24,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  } }
